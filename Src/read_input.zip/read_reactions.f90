! subroutine read_reactions(sig,sig_Er,sig_list,sig_Eex,ncol_mx,sig_type, &
!      npt_mx,rname,col_info,scol_rank,scol_info,sigv_mx,ni0,ntype,n_neu,mpi_rank)
! !     ===================================================================
! !     VERSION:         0.3
! !     LAST MOD:      Nov/15
! !     MOD AUTHOR:    G. Fubiani
! !     COMMENTS:      I am not particularly amateur of goto's,
! !                    (they can be quite confusing) but for this 
! !                    subroutine I make an exception ...
! !
! !     NOTES:         (1) Structure of col_info(reaction ind, info)
! !                     info= 1 -> n1= # of reactants
! !                     info= 2 -> n2= # of byproducts
! !                     info= 3 to 2+n1 -> reactant ptypes
! !                     info= 2+n1 to 2+n1+n2 -> byproduct ptypes  
! !                     info= 2+n1+n2+1 -> reaction type
! !                                        1= COLLISION
! !                                        2= IONIZATION
! !                                        3= EXCITATION
! !                                        4= CHARGEEXCHANGE
! !                                        5= DISSOCIATION
! !                     info= 2+n1+n2+2 -> # of byproduct electrons 
! !                     p_ncol is the number of reactions per ptype
! !
! !                    (2) Structure of sig_list(ptype, icol)
! !                     Reactions are listed per incident particles (not 
! !                     targets)
! !                     icol= cross section number, max is p_ncol(ptype)
! !                     sig_list(ptype, icol)= index of reaction in input
! !                     file
! !
! !                    (3) Structure of scol_info(reaction ind, info)
! !                     info=1 -> incoming particle type 
! !                     info=2 -> reflected particle type (off wall)
! !                     info=3 -> RN
! !                     info=4 -> RE
! !                     p_nscol is the number of wall reactions per ptype
! !
! !                    (4) Structure of scol_rank(ptype, icol)
! !                     Reactions are listed per particle types incident
! !                     on wall
! !                     icol= number of wall reaction, max is p_nscol(ptype)
! !                     scol_rank(ptype, icol)= rank of reaction in list
! !                     order is from smallest to largest.
! !     -------------------------------------------------------------------
!   use mpi
!   implicit none
!   include 'particle_info.h'
!   include 'constants.h'
!   integer:: mpi_rank,ipt,i,j,jmax,npt_mx,icol,ncol_mx,sig_npt(ncol_mx), &
!        sig_type(ncol_mx),sig_list(npart,ncol_mx), &
!        ptype,ntype,flag_pa,flag_re,i_re,r_sy,l_sy, &
!        col_info(ncol_mx,10),n_re,n_by,ind_label,iscol, &
!        scol_rank(npart,ncol_mx),indx(ncol_mx),n_neu
!   real(kind=8):: sig_Er(npt_mx),sig(npt_mx,ncol_mx),sig_Eex(ncol_mx,2), &
!        scol_info(ncol_mx,4),sort_arr(ncol_mx),sig_scale(2),ni0(npart), &
!        sigv_mx(npart,ncol_mx),Ps
!   real(kind=8), allocatable:: sig_tmp(:,:,:)
!   character:: name*4,rname*20,rlabel*50,tname(2)*6,rtype*20
!   parameter ( jmax=10000 )

!   allocate ( sig_tmp(npt_mx,ncol_mx,2) )

!   !
!   ! Open external file
!   !
!   open(10,file='input_dir/'//rname)
!   open(11,file='DATA/particles.out')

!   !
!   ! Initialize variables & arrays
!   !
!   do icol=1,ncol_mx
!      sig_npt(icol)= 0
!      sig_type(icol)= 0
!      do ipt=1,npt_mx
!         sig_Er(ipt)= 0.d0
!         sig(ipt,icol)= 0.d0
!         do j=1,2 
!            sig_tmp(ipt,icol,j)= 0.d0
!         enddo
!      enddo
!   enddo

!   icol=0
!   flag_pa=0
!   flag_re=0
!   col_info=0
!   p_ncol=0
!   iscol=0
!   p_nscol=0
!   sort_arr=0.d0
!   indx=0
!   tag_neg=0
!   tag_neu=0
!   tag_beam=0
!   n_neu=0

!   ! Set electron parameters
!   pname(1)='[e]'
!   charge(1)= -qe
!   mass(1)= 9.10938188d-31
!   ni0(1)=1.d0
!   ntype=1

!   !
!   ! Scan through file
!   !
!   do j=1,jmax

! 19   read(10,*,END=101,ERR=100) name

!      !
!      !  Find section type
!      !

!      ! Ions
!      if( name.eq.'IONS' .or. name.eq.'Ions' .or. name.eq.'ions' ) then
!         flag_pa=1  
!         ! Write info on file
!         if(mpi_rank.eq.0) then 
!            write(11,*) ' '
!            write(11,*) 'Ions:'
!         endif
!         goto 20
!      endif

!      ! Neutrals
!      if( name.eq.'NEUT' .or. name.eq.'Neut' .or. name.eq.'neut' ) then
!         flag_pa=1  
!         ! Write info on file
!         if(mpi_rank.eq.0) then 
!            write(11,*) ' '
!            write(11,*) 'Neutrals:'
!         endif
!         goto 20
!      endif

!      ! Reactions
!      if( name.eq.'REAC' .or. name.eq.'Reac' .or. name.eq.'reac' ) then
!         if (flag_pa.eq.0) goto 101 ! Error
!         ! Add another reaction
!         icol= icol + 1
!         ! Warning
!         if( mpi_rank.eq.0 .and. icol.gt.ncol_mx ) then
!            print*, 'icol > ncol_mx, please correct.'
!            print*, 'Abort simulation ...'           
!            call stop_calculation
!         endif
!         ! Store collision type
!         sig_type(icol)=1 
!         goto 21
!      endif

!      ! Surface reactions
!      if( name.eq.'SURF' .or. name.eq.'Surf' .or. name.eq.'surf' ) then
!         if (flag_pa.eq.0) goto 101 ! Error
!         goto 22
!      endif

!      goto 19 

!      !
!      ! Section dedicated to the definition of ions
!      ! 

!      ! Allows space for some text
! 20   do while(name.ne.'----')
!         read(10,*,END=101,ERR=100) name
!      enddo

! 200  read(10,FMT='(A6)',END=101,ERR=100,ADVANCE='NO') tname(1)

!      if(tname(1)(1:2).eq.'--') then 
!         ! Warning
!         if( mpi_rank.eq.0 .and. ntype.gt.npart ) then
!            print*, 'Warning ntype>npart, please correct ...'
!            call stop_calculation
!         endif
!         goto 99 ! jump to next section 
!      else
!         ntype= ntype + 1 
!         pname(ntype)=tname(1)
!         if(mpi_rank.eq.0) write(11,*) pname(ntype) ! write particle name on file
!         if(pname(ntype).eq.'[H-]') tag_neg= ntype
!         if(pname(ntype).eq.'[H]') tag_neu= ntype
!         if(pname(ntype).eq.'[eb]') tag_beam= ntype
!         read(10,*,END=101,ERR=100) mass(ntype),charge(ntype), &
!              Ti(ntype),ni0(ntype)
!         if( mpi_rank.eq.0 .and. ni0(ntype).gt.1.d0 ) then
!            print*, 'Warning (n/n0)>1 for ', pname(ntype)
!            print*, 'Please correct ...'
!            call stop_calculation
!         endif
!         charge(ntype)= charge(ntype)*qe
!         mass(ntype)= mass(ntype)*amu
!         if(charge(ntype).eq.0.d0) then 
!            n_neu= n_neu + 1
!            ni0(ntype)= ni0(ntype)*ngas
!            ! Neutrals have negative masses
!            mass(ntype)= -ABS(mass(ntype))
!         endif
!         goto 200 ! check for another particle
!      endif

!      !
!      ! Section dedicated to reactions
!      !     
! 21   read(10,*,END=101,ERR=100) rlabel ! Read reaction label

!      ! Write info on file
!      if(flag_re.eq.0) then
!         if(mpi_rank.eq.0) then
!            write(11,*) ' '
!            write(11,*) 'Reactions:'
!         endif
!         flag_re=1
!      endif

!      ! Extract reaction characteristics
!      ind_label=2
!      l_sy=0
!      r_sy=0
!      do i_re=1,50 ! Scan reaction label

!         ! Extract particles name "[.]"
!         if( rlabel(i_re:i_re).eq.'[' ) l_sy=i_re
!         if( rlabel(i_re:i_re).eq.']' ) r_sy=i_re
!         if( rlabel(i_re:i_re).eq.'>' ) then 
!            n_re=ind_label-2
!            ! Save # of reactants
!            col_info(icol,ind_nre)=n_re
!         endif

!         ! Find ptype
!         if(r_sy.gt.l_sy) then 
!            do ptype=1,(ntype+1) ! Loop over particles
!               if( mpi_rank.eq.0 .and. ptype.eq.(ntype+1) ) then
!                  write(*,500) icol 
! 500              format(' Warning: unknown particle in reaction #',1x,i2)
!                  print*, 'Please correct ...'
!                  call stop_calculation
!               endif
!               if( rlabel(l_sy:r_sy).eq.pname(ptype) ) exit
!            enddo
!            ! Save reactant/byproduct ptype
!            ind_label= ind_label + 1 
!            col_info(icol,ind_label)=ptype
!            l_sy=0
!            r_sy=0
!         endif

!      enddo
     
!      ! Save # of byproducts
!      n_by= ind_label - n_re - 2
!      col_info(icol,ind_nby)=n_by


!      ! Read information about energy exchange between species
!      sig_scale=0.d0
!      read(10,*,END=101,ERR=100) sig_Eex(icol,ind_Eth), &
!           sig_Eex(icol,ind_dE)
!      read(10,*,END=101,ERR=100) sig_scale(1),sig_scale(2)
!      read(10,*,END=101,ERR=100) rtype
        
!      sig_Eex(icol,ind_Eth)= sig_Eex(icol,ind_Eth)*sig_scale(1)

!      if( rtype.eq.'COLLISION' .or. rtype.eq.'collision' ) &
!           col_info(icol,ind_nby+1+n_re+n_by)=1
!      if( rtype.eq.'IONIZATION' .or. rtype.eq.'ionization' ) &
!           col_info(icol,ind_nby+1+n_re+n_by)=2
!      if( rtype.eq.'EXCITATION' .or. rtype.eq.'excitation' ) &
!           col_info(icol,ind_nby+1+n_re+n_by)=3
!      if( rtype.eq.'CHARGEEXCHANGE' .or. rtype.eq.'chargeexchange' ) &
!           col_info(icol,ind_nby+1+n_re+n_by)=4
!      if( rtype.eq.'DISSOCIATION' .or. rtype.eq.'dissociation' ) &
!           col_info(icol,ind_nby+1+n_re+n_by)=5
        
!      ! Warning
!      if( mpi_rank.eq.0 .and. col_info(icol,ind_nby+1+n_re+n_by).eq.0 ) then
!         print*, 'Warning: unknown reaction type in reaction #',icol
!         print*, 'Please correct ...'
!         call stop_calculation
!      endif

!      ! Store number of byproduct electrons
!      do i_re=ind_nby+1+n_re,ind_nby+n_re+n_by
!         if(col_info(icol,i_re).eq.1) then
!            col_info(icol,ind_nby+1+n_re+n_by+1)= &
!                 col_info(icol,ind_nby+1+n_re+n_by+1) + 1
!         endif
!      enddo
        
!      ! Allows space for some text
!      do while(name.ne.'----')
!         read(10,*,END=101,ERR=100) name
!      enddo

!      if(mpi_rank.eq.0) write(11,'(i3,1x,a30,1x,f8.2)') icol,rlabel,sig_Eex(icol,ind_Eth) ! write reaction on file 

!      !
!      ! Read data points
!      !
!      do ipt=1,npt_mx


!         ! Warning
!         if( mpi_rank.eq.0 .and. ipt.eq.npt_mx ) then
!            print*, 'Maximum number of data points in cross section reached'
!            print*, 'Abort simulation ...'
!            call stop_calculation
!         endif
        
!         ! Check for end of array string        
!         read(10,FMT='(A)',ADVANCE='NO') name
!         if(name.eq.'----') then
!            read(10,FMT='(A)') name ! reread once more 
!            exit ! exit loop
!         else
!            backspace(10)
!         endif

!         ! Add another data point
!         sig_npt(icol)= sig_npt(icol) + 1

!         read(10,*) sig_tmp(ipt,icol,1), sig_tmp(ipt,icol,2)
!         sig_tmp(ipt,icol,1)= sig_tmp(ipt,icol,1)*sig_scale(1)
!         sig_tmp(ipt,icol,2)= sig_tmp(ipt,icol,2)*sig_scale(2)

!      enddo

!      goto 99 ! Jump to next section 

!      !
!      ! Section dedicated to surface reactions
!      !     
! 22   do while(name.ne.'----') ! Allows space for some text
!         read(10,*,END=101,ERR=100) name
!      enddo

!      ! Write info on file
!      if(mpi_rank.eq.0) then
!         write(11,*) ' '
!         write(11,*) 'Surface reactions:'
!      endif

!      ! Loop over surface reactions
! 220  iscol= iscol + 1 
!      read(10,FMT='(A6)',END=101,ERR=100,ADVANCE='NO') tname(1)

!      if(tname(1)(1:2).eq.'--') then 

!         ! Sort cross-sections
!         nscol= iscol - 1
!         call indexx(nscol,sort_arr,indx)

!         ! Save surface reaction index by particle type and rank
!         do iscol=1,nscol
!            ptype= scol_info(indx(iscol),1)
!            p_nscol(ptype)= p_nscol(ptype) + 1
!            scol_rank(ptype,p_nscol(ptype))= indx(iscol)
!         enddo
        
!         ! Jump to next section 
!         goto 99 

!      else

!         ! read surface reaction characteristics
!         read(10,*,END=101,ERR=100) tname(2),scol_info(iscol,3), & ! RN
!              scol_info(iscol,4) ! RE
     
!         ! write surface reaction on file
!         if(mpi_rank.eq.0) write(11,*) tname(1),tname(2) 

!         ! Find particle labels
!         do i=1,2 ! loop over incident & byproduct particles
!            do ptype=1,(ntype+1) ! loop over particles
!               if( mpi_rank.eq.0 .and. ptype.eq.(ntype+1) ) then
!                  write(*,501) iscol 
! 501              format(' Warning: unknown particle found in surface reaction #',1x,i2)
!                  print*, 'Please correct ...'
!                  call stop_calculation
!               endif
!               if( tname(i).eq.pname(ptype) ) exit
!            enddo
!            ! Save particle type (incident=1 and byproduct=2)
!            scol_info(iscol,i)= ptype 
!         enddo
       
!         ! Temporary store RN
!         sort_arr(iscol)= scol_info(iscol,3)

!         goto 220 ! check for another surface reaction

!      endif

! 99   continue
!   enddo

!   if(mpi_rank.eq.0) then
!      print*, '# of collisions > maximum allowed, please correct'
!      print*, 'Abort calculation ...'
!      call stop_calculation
!   endif
  
! 100 continue
!   !
!   ! Error
!   !
!   if(mpi_rank.eq.0) then
!      print*, 'An error occured while reading cross section #',icol
!      print*, 'Abort calculation ...'
!      call stop_calculation
!   endif

! 101 continue
!   !
!   ! Warnings & messages
!   !
!   if( mpi_rank.eq.0 .and. flag_pa.eq.0 ) then
!      print*, 'Warning: "PARTICLE" section must be placed first, please correct ...'
!      call stop_calculation
!   endif

!   if(mpi_rank.eq.0) print*, 'Gas chemistry read correctly (end of file reached)'
!   ncol=icol

!   if(ngas.eq.0.d0) ncol=0
!   if(ncol.eq.0) then
!      if(mpi_rank.eq.0) print*, 'Collision-less mode is set'
!   else
!      if(mpi_rank.eq.0) print*, 'Total number of reactions:',ncol
!   endif


!   !
!   ! Calculate null collision frequency & rank of collisions (sorting)
!   !
!   call ordering(sig,sig_Er,sig_tmp,sig_npt,sig_list,col_info, &
!        sig_Eex,sigv_mx,ncol_mx,npt_mx,ntype,mpi_rank)


!   !
!   ! Deallocate sig_tmp array
!   !
!   deallocate ( sig_tmp )

!   !
!   ! Check if wall collision probabilities does not exceed one
!   !
!   do ptype=1,ntype
!      Ps= 0.d0
!      do icol=1,p_nscol(ptype)
!         Ps= Ps + scol_info(scol_rank(ptype,icol),3)
!      enddo
!      ! Warning
!      if( mpi_rank.eq.0 .and. Ps.gt.1.d0 ) then
!         print*, 'Total wall collision probability greater than 1 for ',&
!              pname(ptype)
!         print*, 'Please correct ...'
!         call stop_calculation
!      endif
!   enddo

!   !
!   ! Close input file
!   !
!   close(10)
!   close(11)

!   return
! end subroutine read_reactions


! subroutine ordering(sig,sig_Er,sig_tmp,sig_npt,sig_list,col_info, &
!      sig_Eex,sigv_mx,ncol_mx,npt_mx,ntype,mpi_rank)
! !     ==============================================================
! !     VERSION:         0.2
! !     LAST MOD:      Nov/15
! !     MOD AUTHOR:    G. Fubiani
! !     COMMENTS:        /
! !
! !     --------------------------------------------------------------
!   implicit none
!   include 'particle_info.h'
!   include 'constants.h'
!   integer:: ipt,ipt_new,npt,npt_mx,icol,ncol_mx,sig_npt(ncol_mx), &
!        sig_list(npart,ncol_mx),ntype,ptype,length_sort,mpi_rank
!   integer:: col_info(ncol_mx,10),rtype1,rtype2,ind_col(ntype)
!   real(kind=8):: sig_tmp(npt_mx,ncol_mx,2),sig_Er(npt_mx), &
!        sig(npt_mx,ncol_mx),sigv_mx(npart,ncol_mx),mu,vr,&
!        sig_Eex(ncol_mx,2)
!   real(kind=8):: Ek_L,Ek_R,sig_L,sig_R,sig_p,Ekp,sort_Ek_sav,Eth
!   real(kind=8), allocatable :: sort_Ek(:),sort_Ek_tmp(:)
!   integer, allocatable :: indx(:)
!   character:: pnum*1

!   !
!   ! Initialize variables & arrays
!   !
!   sigv_mx=0.d0
!   sig_list=0
!   rtype1=0
!   rtype2=0


!   !
!   ! Concatenate and sort kinetic energies in cross-sections 
!   !
!   length_sort= SUM(sig_npt(1:ncol))
!   allocate ( sort_Ek(length_sort), &
!        sort_Ek_tmp(length_sort), &
!        indx(length_sort) )

!   ! Concatenate
!   ipt_new=0
!   do icol=1,ncol
!      do ipt=1,sig_npt(icol)
!         ipt_new= ipt_new + 1 
!         sort_Ek(ipt_new)= sig_tmp(ipt,icol,1)
!      enddo
!   enddo

!   ! Sort
!   call indexx(length_sort,sort_Ek,indx)           

!   ipt_new=0
!   sort_Ek_sav= 1.d10
!   do ipt=1,length_sort
!      if( sort_Ek(indx(ipt)).ne.sort_Ek_sav ) then
!         ipt_new= ipt_new + 1 
!         sort_Ek_tmp(ipt_new)= sort_Ek(indx(ipt))
!         sort_Ek_sav= sort_Ek_tmp(ipt_new)
!      endif
!   enddo

!   ! Update number of points in cross-section
!   sig_npt_mx= ipt_new

!   ! Warning (only to reassure anxious people ...)
!   if( mpi_rank.eq.0 .and. sig_npt_mx.ge.npt_mx ) then
!      print*, 'sig_npt_mx > npt_mx, please correct'
!      print*, 'sig_npt_mx=',sig_npt_mx
!      print*, 'Abort calculation ...'
!      call stop_calculation
!   endif

!   ! Array storing kinetic energies
!   sig_Er(1:sig_npt_mx)= sort_Ek_tmp(1:sig_npt_mx)

!   deallocate( sort_Ek, sort_Ek_tmp )

!   !
!   ! Extrapolate other cross sections to finest energy grid  
!   !
!   do icol=1,ncol

!      ! Get array length
!      npt=sig_npt(icol)
        
!      ! Threshold energy
!      Eth=sig_Eex(icol,ind_Eth)

!      do ipt=1,sig_npt_mx

!         ! Get stored kinetic energy
!         Ekp= sig_Er(ipt)

!         ! Scan energy from cross-section arrays
!         do ipt_new=1,npt

!            Ek_L= sig_tmp(ipt_new,icol,1)
!            Ek_R= sig_tmp(ipt_new+1,icol,1)
!            sig_L= sig_tmp(ipt_new,icol,2)
!            sig_R= sig_tmp(ipt_new+1,icol,2)           

!            if(Ekp.lt.Ek_L) then 
!               sig_p= sig_L
!               ! Exit loop
!               exit
!            endif

!            if( Ekp.ge.Ek_L .and. Ekp.le.Ek_R ) then 
!               ! Perform linear interpolation
!               sig_p = sig_L + ( Ekp - Ek_L )* & ! Calculate sigma
!                    ( sig_R - sig_L )/( Ek_R - Ek_L )
!               ! Exit loop
!               exit
!            endif

!         enddo

!         ! Warning 
!         if( sig_L.eq.0.d0 .and. sig_R.gt.0.d0) then 
!            if(Eth.gt.Ek_R) then
!               print'(" Eth greater than threshold energy in reaction #",1x,i3)',icol
!               print*, 'Please correct...'
!               call stop_calculation
!            endif
!         endif

!         ! Save interpolated cross-section
!         sig(ipt,icol)= sig_p

!      enddo
!   enddo
 
!   !
!   ! Calculate (sig*v)_max & rank of cross-sections
!   !
!   ind_col=0
!   do icol=1,ncol

!      ! List cross sections per incident particles
!      rtype1= col_info(icol,ind_nby+1)
!      ind_col(rtype1)= ind_col(rtype1) + 1 
!      sig_list(rtype1,ind_col(rtype1))= icol

!      do ipt=1,sig_npt_mx

!         ! Reduced mass
!         rtype1= col_info(icol,ind_nby+1)
!         rtype2= col_info(icol,ind_nby+2)
!         mu=ABS(mass(rtype1))*ABS(mass(rtype2))/ &
!              (ABS(mass(rtype1))+ABS(mass(rtype2)))

!         ! Calculate relative velocity (energy in eV)
!         vr= dsqrt(2.d0*sig_Er(ipt)*qe/mu)
  
!         ! Calculate ( sig*v_r )_max
!         if(sig_Er(ipt).ge.1.d0) & ! Cut off at 1. eV
!              sigv_mx(rtype1,icol)= MAX( sigv_mx(rtype1,icol), vr*sig(ipt,icol) )

!      enddo

!   enddo

!   ! Save number of reactions per particle specie
!   p_ncol(1:ntype)= ind_col(1:ntype)


!   ! Save cross sections per common reactant
!   if(mpi_rank.eq.0) then
!      do ptype=1,ntype
!         write (pnum,'(i1)'),ptype
!         open(10,file='DATA/reactions.'//pnum)
!         do icol=1,p_ncol(ptype)
!            do ipt=1,sig_npt_mx
!               write(10,'(1x,f12.4,1x,es12.4)') sig_Er(ipt), &
!                    sig(ipt,sig_list(ptype,icol))  
!            enddo
!            write(10,*) ' '
!         enddo
!         close(10)
!      enddo
!   endif

!   return
! end subroutine ordering

!==============================================================
!  mod_reactions.f90  (clean, OOP-friendly, insightful names)
!  - Reads REACTION blocks & σ(E) tables from chemistry file
!  - Provides σ(E) interpolation and (σ v_rel)_max ceilings
!  - Writes a summary into ./Outputs/particles.out
!  - Optional σ(E) dumps grouped by incident species
!  - Uses proper Fortran ENUM with iso_c_binding (c_int)
!==============================================================
module mod_reactions
  use iso_fortran_env, only: real64, int32, output_unit
  use iso_c_binding,   only: c_int
  use mod_InputFiles,  only: find_particles_file
  use mod_functionsText            ! expects: is_dashed(), split_ws(), etc.
  use mod_particles,   only: SpeciesTable, species_index_of
  use mpi
  implicit none
  private

  !----------------------- Enumerated kinds -----------------------
  enum, bind(c)
    enumerator :: REACT_ELASTIC      = 1_c_int
    enumerator :: REACT_IONIZATION   = 2_c_int
    enumerator :: REACT_EXCITATION   = 3_c_int
    enumerator :: REACT_CHARGEEXCH   = 4_c_int
    enumerator :: REACT_DISSOCIATION = 5_c_int
    ! extra short-tags you mentioned
    enumerator :: REACT_DATT         = 6_c_int
    enumerator :: REACT_DION         = 7_c_int
    enumerator :: REACT_DISS         = 8_c_int
    enumerator :: REACT_ELA          = 9_c_int
    enumerator :: REACT_EXC          = 10_c_int
  end enum

  public :: REACT_ELASTIC, REACT_IONIZATION, REACT_EXCITATION, REACT_CHARGEEXCH, REACT_DISSOCIATION, &
            REACT_DATT, REACT_DION, REACT_DISS, REACT_ELA, REACT_EXC

  !---------------------- Public types / API ----------------------
  type :: CrossSectionTable
     real(real64), allocatable :: energy_eV_list(:)
     real(real64), allocatable :: cross_section_m2_list(:)
  end type

  type :: Reaction
     ! Species mapping
     integer :: num_reactants = 0
     integer :: num_products  = 0
     integer :: reactant_species_index(4) = 0  !! up to 4 reactants
     integer :: product_species_index(6)  = 0  !! up to 6 products

     ! Kind and metadata
     integer(c_int) :: type_id       = REACT_ELASTIC
     real(real64)   :: threshold_eV  = 0.0_real64   !! Eth
     real(real64)   :: heavy_gain_eV = 0.0_real64   !! dE to heavy byproducts
     real(real64)   :: scale_energy  = 1.0_real64   !! scale applied to E column
     real(real64)   :: scale_sigma   = 1.0_real64   !! scale applied to σ column
     integer        :: product_electron_count = 0

     type(CrossSectionTable) :: table
     character(len=:), allocatable :: label_text   !! "[e]+[H]->[e]+[H+]+[e]"
  end type

  type :: ReactionSet
     type(Reaction), allocatable :: list(:)
  end type

  public :: CrossSectionTable, Reaction, ReactionSet
  public :: load_reactions_from_file
  public :: sigma_at_energy
  public :: count_reactions, reaction_at
  public :: compute_sigv_ceiling_all
  public :: write_reactions_to_particles_out  ! new
  public :: write_sigma_grouped_by_incident    ! new

contains
  !================================================================
  ! Read all REACTION blocks + σ(E) tables from chemistry file
  !================================================================
  subroutine load_reactions_from_file(out_reactions, species_catalog)
    type(ReactionSet), intent(out) :: out_reactions
    type(SpeciesTable),intent(in)  :: species_catalog
    integer :: u, ios
    character(len=512) :: line

    if (allocated(out_reactions%list)) deallocate(out_reactions%list)
    allocate(out_reactions%list(0))

    open(newunit=u, file=trim(find_particles_file()), status='old', action='read', iostat=ios)
    if (ios /= 0) error stop 'mod_reactions: cannot open chemistry file.'

    do
      read(u,'(A)', iostat=ios) line
      if (ios /= 0) exit
      call strip_comment(line)
      if (len_trim(line) == 0) cycle

      if (starts_with(trim(line), 'REACTION')) then
        call parse_one_reaction_block(u, out_reactions, species_catalog)
      end if
    end do
    close(u)

    write(output_unit,'(A,I0)') 'Reactions loaded = ', count_reactions(out_reactions)
  end subroutine load_reactions_from_file

  !================================================================
  ! σ(E) interpolation (linear, clamped at bounds)
  !================================================================
  pure function sigma_at_energy(table, energy_eV) result(sigma_m2)
    type(CrossSectionTable), intent(in) :: table
    real(real64),            intent(in) :: energy_eV
    real(real64) :: sigma_m2
    integer :: n, iL

    sigma_m2 = 0.0_real64
    n = size(table%energy_eV_list)
    if (n == 0) return

    if (energy_eV <= table%energy_eV_list(1)) then
      sigma_m2 = table%cross_section_m2_list(1); return
    end if
    if (energy_eV >= table%energy_eV_list(n)) then
      sigma_m2 = table%cross_section_m2_list(n); return
    end if

    do iL = 1, n-1
      if (energy_eV >= table%energy_eV_list(iL) .and. energy_eV <= table%energy_eV_list(iL+1)) then
        sigma_m2 = lin_interp(energy_eV,                             &
                              table%energy_eV_list(iL),               &
                              table%energy_eV_list(iL+1),             &
                              table%cross_section_m2_list(iL),        &
                              table%cross_section_m2_list(iL+1))
        return
      end if
    end do
  end function sigma_at_energy

  !================================================================
  ! Utilities for sets
  !================================================================
  pure function count_reactions(reactions) result(n)
    type(ReactionSet), intent(in) :: reactions
    integer :: n
    if (.not. allocated(reactions%list)) then
      n = 0
    else
      n = size(reactions%list)
    end if
  end function count_reactions

  pure function reaction_at(reactions, i) result(r)
    type(ReactionSet), intent(in) :: reactions
    integer,           intent(in) :: i
    type(Reaction) :: r
    r = reactions%list(i)
  end function reaction_at

  !================================================================
  ! (σ v_rel)_max per reaction (null-collision ceiling)
  !   v_rel = sqrt(2 * E * e / μ), μ = reduced mass of first 2 reactants
  !================================================================
  subroutine compute_sigv_ceiling_all(reactions, species_catalog, sigv_ceiling)
    type(ReactionSet), intent(in)  :: reactions
    type(SpeciesTable),intent(in)  :: species_catalog
    real(real64), allocatable, intent(out) :: sigv_ceiling(:)
    integer :: i, n

    n = count_reactions(reactions)
    allocate(sigv_ceiling(n)); sigv_ceiling = 0.0_real64

    do i = 1, n
      sigv_ceiling(i) = sigv_ceiling_one(reactions%list(i), species_catalog)
    end do
  end subroutine compute_sigv_ceiling_all

  !======================== Internal ============================

  subroutine parse_one_reaction_block(u, out_reactions, species_catalog)
    integer,             intent(in)    :: u
    type(ReactionSet),   intent(inout) :: out_reactions
    type(SpeciesTable),  intent(in)    :: species_catalog

    type(Reaction) :: rx
    integer :: ios
    character(len=512) :: line

    ! label
    read(u,'(A)', iostat=ios) line; call expect_ok(ios, 'Missing reaction label.')
    call strip_comment(line); rx%label_text = trim(line)
    call parse_label_species(rx%label_text, rx, species_catalog)

    ! Eth dE
    read(u,'(A)', iostat=ios) line; call expect_ok(ios, 'Missing "Eth dE".'); call strip_comment(line)
    call read_two_reals(line, rx%threshold_eV, rx%heavy_gain_eV)

    ! scale_E scale_sigma
    read(u,'(A)', iostat=ios) line; call expect_ok(ios, 'Missing "scale_E scale_sigma".'); call strip_comment(line)
    call read_two_reals(line, rx%scale_energy, rx%scale_sigma)

    ! kind
    read(u,'(A)', iostat=ios) line; call expect_ok(ios, 'Missing reaction kind.'); call strip_comment(line)
    rx%type_id = map_kind_string(trim(line))

    ! seek NOTES
    do
      read(u,'(A)', iostat=ios) line; if (ios /= 0) exit
      call strip_comment(line)
      if (index(uppercase(trim(line)), 'NOTES') > 0) exit
    end do
    ! skip header line
    read(u,'(A)', iostat=ios) line; call expect_ok(ios, 'Unexpected EOF before σ(E) table.')

    ! read E-σ pairs
    call read_sigma_pairs(u, rx%table, rx%scale_energy, rx%scale_sigma)

    ! count product electrons
    rx%product_electron_count = count(rx%product_species_index(1:rx%num_products) == &
                                      species_index_of(species_catalog, '[e]'))

    call push_reaction(out_reactions, rx)
  end subroutine parse_one_reaction_block

  pure function sigv_ceiling_one(rx, species_catalog) result(max_sigv)
    type(Reaction),     intent(in) :: rx
    type(SpeciesTable), intent(in) :: species_catalog
    real(real64) :: max_sigv
    real(real64) :: mu, E, vr
    integer :: n, i
    real(real64) :: m1, m2
    real(real64), parameter :: e_charge = 1.602176634e-19_real64

    max_sigv = 0.0_real64
    if (rx%num_reactants < 2) return

    m1 = abs(species_catalog%species(rx%reactant_species_index(1))%mass)
    m2 = abs(species_catalog%species(rx%reactant_species_index(2))%mass)
    if (m1 <= 0.0_real64 .or. m2 <= 0.0_real64) return

    mu = (m1*m2)/(m1+m2)
    n  = size(rx%table%energy_eV_list)

    do i = 1, n
      E  = max(1.0_real64, rx%table%energy_eV_list(i))  ! avoid 0 eV
      vr = sqrt(2.0_real64 * E * e_charge / mu)
      max_sigv = max(max_sigv, vr * rx%table%cross_section_m2_list(i))
    end do
  end function sigv_ceiling_one

  subroutine read_sigma_pairs(u, table, scale_E, scale_sigma)
    integer,                intent(in)  :: u
    type(CrossSectionTable),intent(out) :: table
    real(real64),           intent(in)  :: scale_E, scale_sigma
    character(len=256) :: line
    integer :: ios
    real(real64) :: E, S

    if (allocated(table%energy_eV_list)) deallocate(table%energy_eV_list, table%cross_section_m2_list)
    allocate(table%energy_eV_list(0), table%cross_section_m2_list(0))

    do
      read(u,'(A)', iostat=ios) line
      if (ios /= 0) exit
      call strip_comment(line)
      if (len_trim(line) == 0) cycle
      if (is_dashed(trim(line))) exit

      read(line,*,iostat=ios) E, S
      if (ios /= 0) cycle
      call push_sigma_point(table, E*scale_E, max(0.0_real64, S*scale_sigma))
    end do

    call enforce_strictly_increasing(table%energy_eV_list)
  end subroutine read_sigma_pairs

  subroutine parse_label_species(label, rx, species_catalog)
    character(len=*), intent(in)    :: label
    type(Reaction),   intent(inout) :: rx
    type(SpeciesTable),intent(in)   :: species_catalog

    character(len=:), allocatable :: lhs, rhs
    character(len=256) :: token_list(32)
    integer :: n_tok, i, idx

    call split_by_arrow(trim(label), lhs, rhs)

    ! reactants (split '+' only outside brackets)
    call split_species_list(lhs, token_list, n_tok)
    rx%num_reactants = 0
    do i=1,n_tok
      idx = species_index_of(species_catalog, trim(token_list(i)))
      if (idx > 0) then
        rx%num_reactants = rx%num_reactants + 1
        rx%reactant_species_index(rx%num_reactants) = idx
      else
        write(output_unit,'(A)') 'Unknown reactant: '//trim(token_list(i))//'  <<'//trim(label)//'>>'
      end if
    end do

    ! products (split '+' only outside brackets)
    call split_species_list(rhs, token_list, n_tok)
    rx%num_products = 0
    do i=1,n_tok
      idx = species_index_of(species_catalog, trim(token_list(i)))
      if (idx > 0) then
        rx%num_products = rx%num_products + 1
        rx%product_species_index(rx%num_products) = idx
      else
        write(output_unit,'(A)') 'Unknown product: '//trim(token_list(i))//'  <<'//trim(label)//'>>'
      end if
    end do
  end subroutine parse_label_species

  !---------------------- small helpers -------------------------
  pure function lin_interp(x, xL, xR, yL, yR) result(y)
    real(real64), intent(in) :: x, xL, xR, yL, yR
    real(real64) :: y
    if (xR > xL) then
      y = yL + (x - xL) * (yR - yL) / (xR - xL)
    else
      y = yL
    end if
  end function lin_interp

  subroutine push_sigma_point(table, E, S)
    type(CrossSectionTable), intent(inout) :: table
    real(real64),            intent(in)    :: E, S
    integer :: n
    real(real64), allocatable :: e_tmp(:), s_tmp(:)
    n = size(table%energy_eV_list)
    allocate(e_tmp(n+1), s_tmp(n+1))
    if (n > 0) then
      e_tmp(1:n) = table%energy_eV_list
      s_tmp(1:n) = table%cross_section_m2_list
      deallocate(table%energy_eV_list, table%cross_section_m2_list)
    end if
    e_tmp(n+1) = E
    s_tmp(n+1) = S
    call move_alloc(e_tmp, table%energy_eV_list)
    call move_alloc(s_tmp, table%cross_section_m2_list)
  end subroutine push_sigma_point

  subroutine enforce_strictly_increasing(a)
    real(real64), intent(inout) :: a(:)
    integer :: i, n
    real(real64) :: last, eps
    n = size(a); if (n <= 1) return
    eps = epsilon(1.0_real64)
    last = a(1)
    do i = 2, n
      if (a(i) <= last) a(i) = last + max(eps, abs(last)*eps)
      last = a(i)
    end do
  end subroutine enforce_strictly_increasing

  integer(c_int) function map_kind_string(s) result(k)
    character(len=*), intent(in) :: s
    character(len=:), allocatable :: u
    u = uppercase(trim(s))
    select case (u)
    case ('COLLISION');      k = REACT_ELASTIC
    case ('IONIZATION');     k = REACT_IONIZATION
    case ('EXCITATION');     k = REACT_EXCITATION
    case ('CHARGEEXCHANGE'); k = REACT_CHARGEEXCH
    case ('DISSOCIATION');   k = REACT_DISSOCIATION
    case ('DATT');           k = REACT_DATT
    case ('DION');           k = REACT_DION
    case ('DISS');           k = REACT_DISS
    case ('ELA');            k = REACT_ELA
    case ('EXC');            k = REACT_EXC
    case default;            k = REACT_ELASTIC
    end select
  end function map_kind_string

  pure function uppercase(s) result(t)
    character(len=*), intent(in) :: s
    character(len=len_trim(s)) :: t
    integer :: i, n, a
    n = len_trim(s)
    do i=1,n
      a = iachar(s(i:i))
      if (a >= iachar('a') .and. a <= iachar('z')) then
        t(i:i) = achar(a - 32)
      else
        t(i:i) = s(i:i)
      end if
    end do
  end function uppercase

  ! Split on '+' only when not inside [...]
  subroutine split_species_list(side, tokens, n_tok)
    character(len=*), intent(in)  :: side
    character(len=*), intent(out) :: tokens(:)
    integer,          intent(out) :: n_tok

    character(len=:), allocatable :: s
    integer :: i, n, start_pos, depth
    character(len=1) :: ch

    s = adjustl(trim(side))
    n = len_trim(s)
    n_tok = 0
    start_pos = 1
    depth = 0  ! bracket nesting depth

    do i = 1, max(1,n)
       ch = s(i:i)
       select case (ch)
       case ('['); depth = depth + 1
       case (']'); if (depth > 0) depth = depth - 1
       case ('+')
          if (depth == 0) then
             if (i-1 >= start_pos) then
                n_tok = n_tok + 1
                tokens(n_tok) = adjustl(trim(s(start_pos:i-1)))
             end if
             start_pos = i + 1
          end if
       end select
    end do

    if (n >= start_pos) then
       n_tok = n_tok + 1
       tokens(n_tok) = adjustl(trim(s(start_pos:n)))
    end if
  end subroutine split_species_list

  subroutine split_by_arrow(label, lhs, rhs)
    character(len=*), intent(in)  :: label
    character(len=:), allocatable, intent(out) :: lhs, rhs
    integer :: pos
    pos = index(label, '->')
    if (pos <= 0) then
      lhs = trim(label); rhs = ''
    else
      lhs = trim(label(:pos-1))
      rhs = trim(label(pos+2:))
    end if
  end subroutine split_by_arrow

  pure logical function starts_with(s, prefix)
    character(len=*), intent(in) :: s, prefix
    integer :: n
    n = len_trim(prefix)
    if (len_trim(s) < n) then
      starts_with = .false.
    else
      starts_with = (s(1:n) == prefix(1:n))
    end if
  end function starts_with

  subroutine strip_comment(line)
    character(len=*), intent(inout) :: line
    integer :: p
    p = index(line, '!')
    if (p > 0) line = line(:p-1)
  end subroutine strip_comment

  subroutine read_two_reals(text, a, b)
    character(len=*), intent(in)  :: text
    real(real64),     intent(out) :: a, b
    integer :: ios
    read(text,*,iostat=ios) a, b
    call expect_ok(ios, 'Expected two real numbers.')
  end subroutine read_two_reals

  subroutine push_reaction(set, rx)
    type(ReactionSet), intent(inout) :: set
    type(Reaction),    intent(in)    :: rx
    type(Reaction), allocatable :: tmp(:)
    integer :: n
    n = count_reactions(set)
    allocate(tmp(n+1))
    if (n > 0) tmp(1:n) = set%list
    tmp(n+1) = rx
    if (allocated(set%list)) deallocate(set%list)
    call move_alloc(tmp, set%list)
  end subroutine push_reaction

  subroutine expect_ok(ios, msg)
    integer,         intent(in) :: ios
    character(len=*),intent(in) :: msg
    if (ios /= 0) error stop trim(msg)
  end subroutine expect_ok

  !==============================================================
  !  Writers (summary to particles.out; optional σ(E) dumps)
  !==============================================================
  subroutine write_reactions_to_particles_out(reactions, species_catalog, write_sigma_files)
    type(ReactionSet), intent(in) :: reactions
    type(SpeciesTable),intent(in) :: species_catalog
    logical, optional, intent(in) :: write_sigma_files

    integer :: ierr, rank_local, i, u, ios
    character(len=*), parameter :: outFile = './Outputs/particles.out'
    logical :: do_sigma
    do_sigma = .false.; if (present(write_sigma_files)) do_sigma = write_sigma_files

    call MPI_Comm_rank(MPI_COMM_WORLD, rank_local, ierr)
    if (rank_local /= 0) return

    call execute_command_line('mkdir -p ./Outputs', exitstat=ios)

    open(newunit=u, file=outFile, status='unknown', action='write', position='append', iostat=ios)
    if (ios /= 0) then
      write(output_unit,'(A)') 'write_reactions_to_particles_out: cannot open '//trim(outFile)
      return
    end if

    write(u,'(A)') ' '
    write(u,'(A)') 'Reactions:'
    do i = 1, count_reactions(reactions)
      write(u,'(I3,1X,A,1X,"Eth=",F10.3," eV",1X,"type=",A)') i, &
        trim(default_if_empty(reactions%list(i)%label_text,'(unlabeled)')), &
        reactions%list(i)%threshold_eV, trim(reaction_type_name(reactions%list(i)%type_id))
    end do
    write(u,'(A,I0)') 'Total number of reactions: ', count_reactions(reactions)
    close(u)

    if (do_sigma) call write_sigma_grouped_by_incident(reactions, species_catalog)
  end subroutine write_reactions_to_particles_out

  subroutine write_sigma_grouped_by_incident(reactions, species_catalog)
    type(ReactionSet), intent(in) :: reactions
    type(SpeciesTable),intent(in) :: species_catalog

    integer :: ierr, rank_local, i, s, u, ios, n, k
    character(len=32)  :: idxstr
    character(len=256) :: path

    call MPI_Comm_rank(MPI_COMM_WORLD, rank_local, ierr)
    if (rank_local /= 0) return

    call execute_command_line('mkdir -p ./Outputs', exitstat=ios)

    do s = 1, species_catalog%number_species
      write(idxstr,'(I0)') s
      path = './Outputs/reactions.'//trim(idxstr)
      open(newunit=u, file=path, status='replace', action='write', iostat=ios)
      if (ios /= 0) then
        write(output_unit,'(A)') 'write_sigma_grouped_by_incident: cannot open '//trim(path)
        cycle
      end if

      do i = 1, count_reactions(reactions)
        if (reactions%list(i)%num_reactants >= 1) then
          if (reactions%list(i)%reactant_species_index(1) == s) then
            n = size(reactions%list(i)%table%energy_eV_list)
            if (n > 0) then
              write(u,'(A)') trim(default_if_empty(reactions%list(i)%label_text,'(unlabeled)'))
              write(u,'(A)') '# E[eV]    sigma[m^2]'
              do k = 1, n
                write(u,'(F12.4,1X,ES14.6)') reactions%list(i)%table%energy_eV_list(k), &
                                            reactions%list(i)%table%cross_section_m2_list(k)
              end do
              write(u,'(A)') ' '
            end if
          end if
        end if
      end do
      close(u)
    end do
  end subroutine write_sigma_grouped_by_incident

  !---------------------- tiny helpers for writers ---------------
  pure function reaction_type_name(k) result(name)
    integer(c_int), intent(in) :: k
    character(len=24) :: name
    select case (k)
    case (REACT_ELASTIC)     ; name = 'ELASTIC'
    case (REACT_IONIZATION)  ; name = 'IONIZATION'
    case (REACT_EXCITATION)  ; name = 'EXCITATION'
    case (REACT_CHARGEEXCH)  ; name = 'CHARGEEXCHANGE'
    case (REACT_DISSOCIATION); name = 'DISSOCIATION'
    case (REACT_DATT)        ; name = 'DATT'
    case (REACT_DION)        ; name = 'DION'
    case (REACT_DISS)        ; name = 'DISS'
    case (REACT_ELA)         ; name = 'ELA'
    case (REACT_EXC)         ; name = 'EXC'
    case default             ; name = 'UNKNOWN'
    end select
  end function reaction_type_name

  pure function default_if_empty(s, fallback) result(out)
    character(len=*), intent(in) :: s, fallback
    character(len=:), allocatable :: out
    if (len_trim(s) == 0) then
      out = trim(fallback)
    else
      out = trim(s)
    end if
  end function default_if_empty

end module mod_reactions
