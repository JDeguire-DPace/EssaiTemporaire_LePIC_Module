module mod_poisson_stub_driver
  use iso_fortran_env, only: real64
  use mpi
  use mod_poisson_decomp, only: PoissonDecomp
  implicit none
  private
  public :: run_poisson_stub

  ! Give the compiler the interface of the legacy routine
  interface
    subroutine pdesolver(u,b,bcnd,h,n,ncycl,eps,omega,k,ktot,res,ng,rank,nproc)
      use iso_fortran_env, only: real64
      implicit none
      integer, intent(in) :: n(3), ng, ncycl, rank, nproc
      integer, intent(inout) :: k
      real(real64), intent(inout) :: h(3)
      real(real64), intent(inout) :: u(0:n(1)+2,0:n(2)+2,-1:n(3)/nproc+2)
      real(real64), intent(inout) :: b(0:n(1)+1,0:n(2)+1,0:n(3)/nproc+1)
      integer,      intent(inout) :: bcnd(0:n(1)+2,0:n(2)+2,0:n(3)/nproc+2)
      real(real64), intent(in)    :: eps, omega
      real(real64), intent(inout) :: ktot, res
    end subroutine pdesolver
  end interface

contains

  subroutine run_poisson_stub(comm, n, h, bcnd_global, phi_global)
    integer, intent(in) :: comm
    integer, intent(in) :: n(3)
    real(real64), intent(in) :: h(3)
    integer, intent(in) :: bcnd_global(0:n(1)+2,0:n(2)+2,0:n(3)+2)
    real(real64), intent(inout) :: phi_global(0:n(1)+2,0:n(2)+2,0:n(3)+2)

    type(PoissonDecomp) :: pdec
    integer :: rank, nproc, ierr
    integer :: m
    real(real64), allocatable :: b_loc(:,:,:)
    integer,      allocatable :: bcnd_loc(:,:,:)
    real(real64), allocatable :: u_mg(:,:,:)

    integer :: ng, ncycl, k
    real(real64) :: eps, omega, ktot, res
    real(real64) :: h_mg(3)
    h_mg = h
    

    call MPI_Comm_rank(comm, rank, ierr)
    call MPI_Comm_size(comm, nproc, ierr)

    ! IMPORTANT: PoissonDecomp%init must accept integer comm if it uses `use mpi`
    call pdec%init(n(1), n(2), n(3), comm)

    m = n(3) / nproc

    allocate(u_mg(0:n(1)+2, 0:n(2)+2, -1:m+2))
    allocate(b_loc(0:n(1)+1, 0:n(2)+1,  0:m+1))
    allocate(bcnd_loc(0:n(1)+2,0:n(2)+2, 0:m+2))

    u_mg     = 0.0_real64
    b_loc    = 0.0_real64
    bcnd_loc = 0

    call pdec%scatter_from_global(phi_global, bcnd_global)

    u_mg(:,:,0:m+2)     = pdec%phi_dom(:,:,0:m+2)
    bcnd_loc(:,:,0:m+2) = pdec%bcnd_dom(:,:,0:m+2)

    call build_rhs_gaussian(n, h, pdec%k0, m, b_loc, bcnd_loc)

    ng    = 6
    ncycl = 50
    eps   = 1.0e-6_real64
    omega = 1.7_real64
    ktot  = 0.0_real64
    res   = 0.0_real64
    k     = 0

    call pdesolver(u_mg, b_loc, bcnd_loc, h_mg, n, ncycl, eps, omega, k, ktot, res, ng, rank, nproc)

    pdec%phi_dom(:,:,0:m+2) = u_mg(:,:,0:m+2)
    call pdec%gather_phi_to_global(phi_global)

    call pdec%destroy()
    deallocate(u_mg, b_loc, bcnd_loc)
  end subroutine run_poisson_stub


  subroutine build_rhs_gaussian(n, h, k0, m, b_loc, bcnd_loc)
    integer, intent(in)          :: n(3)
    real(real64), intent(in)     :: h(3)
    integer, intent(in)          :: k0, m
    real(real64), intent(inout)  :: b_loc(0:n(1)+1,0:n(2)+1,0:m+1)
    integer, intent(in)          :: bcnd_loc(0:n(1)+2,0:n(2)+2,0:m+2)

    integer :: i,j,k
    real(real64) :: x,y,z
    real(real64) :: x0,y0,z0, sig2, amp

    x0 = 0.5_real64 * (n(1)*h(1))
    y0 = 0.5_real64 * (n(2)*h(2))
    z0 = 0.5_real64 * (n(3)*h(3))

    sig2 = (0.10_real64 * n(1)*h(1))**2
    amp  = 1.0_real64

    b_loc = 0.0_real64

    do k=0,m+1
      z = real(k0 + k, real64) * h(3)
      do j=0,n(2)+1
        y = real(j, real64) * h(2)
        do i=0,n(1)+1
          x = real(i, real64) * h(1)
          if (bcnd_loc(i,j,k) <= 0) then
            b_loc(i,j,k) = -amp * exp(-((x-x0)**2 + (y-y0)**2 + (z-z0)**2)/sig2)
          end if
        end do
      end do
    end do
  end subroutine build_rhs_gaussian

end module mod_poisson_stub_driver
