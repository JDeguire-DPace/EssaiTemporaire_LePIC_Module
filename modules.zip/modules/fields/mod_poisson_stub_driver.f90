module mod_poisson_stub_driver
  use iso_fortran_env, only: real64
  use mpi
  use mod_poisson_decomp, only: PoissonDecomp
  use mod_constants,    only: eps0
  implicit none
  private
  public :: run_poisson_stub, write_mco_real_xy

  ! Give the compiler the interface of the legacy routine
  interface
    subroutine pdesolver(u,b,bcnd,h,n,ncycl,eps,omega,k,ktot,res,ng,rank,nproc)
      use iso_fortran_env, only: real64
      implicit none
      integer, intent(in) :: n(3), ng, ncycl, rank, nproc
      integer, intent(inout) :: k
      real(real64), intent(inout) :: h(3)
      real(real64), intent(inout) :: u(0:n(1)+2,0:n(2)+2,-1:n(3)/nproc+2)
      real(real64), intent(inout) :: b(0:n(1)+1,0:n(2)+1,0:n(3)/nproc+1)
      integer,      intent(inout) :: bcnd(0:n(1)+2,0:n(2)+2,0:n(3)/nproc+2)
      real(real64), intent(in)    :: eps, omega
      real(real64), intent(inout) :: ktot, res
    end subroutine pdesolver
  end interface

contains

  subroutine run_poisson_stub(comm, n, h, bcnd_global, phi_global)
    integer, intent(in) :: comm
    integer, intent(in) :: n(3)
    real(real64), intent(in) :: h(3)
    integer, intent(in) :: bcnd_global(0:n(1)+2,0:n(2)+2,0:n(3)+2)
    real(real64), intent(inout) :: phi_global(0:n(1)+2,0:n(2)+2,0:n(3)+2)

    type(PoissonDecomp) :: pdec
    integer :: rank, nproc, ierr
    integer :: m
    real(real64), allocatable :: b_loc(:,:,:)
    integer,      allocatable :: bcnd_loc(:,:,:)
    real(real64), allocatable :: u_mg(:,:,:)
    real(real64) :: local_sum, global_sum
    real(real64) :: local_vol, global_vol

    integer :: ng, ncycl, k
    real(real64) :: eps, omega, ktot, res
    real(real64) :: h_mg(3)
    h_mg = h
    

    call MPI_Comm_rank(comm, rank, ierr)
    call MPI_Comm_size(comm, nproc, ierr)

    ! IMPORTANT: PoissonDecomp%init must accept integer comm if it uses `use mpi`
    call pdec%init(n(1), n(2), n(3), comm)

    m = n(3) / nproc

    allocate(u_mg(0:n(1)+2, 0:n(2)+2, -1:m+2))
    allocate(b_loc(0:n(1)+1, 0:n(2)+1,  0:m+1))
    allocate(bcnd_loc(0:n(1)+2,0:n(2)+2, 0:m+2))

    u_mg     = 0.0_real64
    b_loc    = 0.0_real64
    bcnd_loc = 0

    call pdec%scatter_from_global(phi_global, bcnd_global)

    u_mg(:,:,0:m+2)     = pdec%phi_dom(:,:,0:m+2)
    bcnd_loc(:,:,0:m+2) = pdec%bcnd_dom(:,:,0:m+2)

    call build_rhs_gaussian(n, h, pdec%k0, m, b_loc, bcnd_loc)

    ng    = 6
    ncycl = 50
    eps   = 1.0e-6_real64
    omega = 1.7_real64
    ktot  = 0.0_real64
    res   = 0.0_real64
    k     = 0

    

    local_sum = sum(b_loc(1:n(1)+1,1:n(2)+1,1:m))
    call MPI_Allreduce(local_sum, global_sum, 1, MPI_DOUBLE_PRECISION, MPI_SUM, comm, ierr)

    if (rank == 0) then
      print*, "Global RHS sum =", global_sum
    end if

    call pdesolver(u_mg, b_loc, bcnd_loc, h_mg, n, ncycl, eps, omega, k, ktot, res, ng, rank, nproc)

    pdec%phi_dom(:,:,lbound(pdec%phi_dom,3):ubound(pdec%phi_dom,3)) = &
        u_mg(:,:,lbound(pdec%phi_dom,3):ubound(pdec%phi_dom,3))
    call pdec%gather_phi_to_global(phi_global)

    call pdec%destroy()
    deallocate(u_mg, b_loc, bcnd_loc)
  end subroutine run_poisson_stub


  subroutine build_rhs_gaussian(n, h, k0, m, b_loc, bcnd_loc)
    integer, intent(in)          :: n(3)
    real(real64), intent(in)     :: h(3)
    integer, intent(in)          :: k0, m
    real(real64), intent(inout)  :: b_loc(0:n(1)+1,0:n(2)+1,0:m+1)
    integer, intent(in)          :: bcnd_loc(0:n(1)+2,0:n(2)+2,0:m+2)

    integer :: i,j,k
    real(real64) :: x,y,z
    real(real64) :: x0,y0,z0, sig2, amp

    x0 = 0.5_real64 * (n(1)*h(1))
    y0 = 0.5_real64 * (n(2)*h(2))
    z0 = 0.5_real64 * (n(3)*h(3))

    sig2 = (5.0e-2_real64)**2
    amp  = 1.0e-6_real64

    b_loc = 0.0! - 10.0_real64/(3.0_real64)   ! scale factor to get from a physical charge density (C/m^3) to the appropriate RHS units for the Poisson equation in V/m^2, assuming a grid spacing of order 1e-2 m. Adjust as needed for your specific grid and physical scenario.

    ! do k=0,m+1
    !   z = real(k0 + k, real64) * h(3)
    !   do j=0,n(2)+1
    !     y = real(j, real64) * h(2)
    !     do i=0,n(1)+1
    !       x = real(i, real64) * h(1)
    !       if (bcnd_loc(i,j,k) <= 0) then
    !         b_loc(i,j,k) = (1.0_real64/sqrt(2.0_real64*3.141592_real64*sig2))*(1.6022e-19_real64 * 1e12_real64/eps0) * exp(-((x-x0)**2 + (y-y0)**2 + (z-z0)**2)/(2.0_real64*sig2))*(x**2-2.0_real64*x*x0+x0**2+ &
    !             y**2-2.0_real64*y*y0+y0**2 + z**2-2.0_real64*z*z0+z0**2 - 3.0_real64*sig2)/sig2**2
    !          ! For a Gaussian source, the "Poisson form" consistent with ∇²phi = -rho/eps0 is b_loc = -rho/eps0, where rho = amp * exp(-r^2/(2*sig^2)). The Laplacian of a Gaussian gives the additional polynomial factor. You can adjust the amplitude and width of the Gaussian by changing amp and sig2.
    !          !
    !        ! b_loc(i,j,k) = -amp * exp(-((x-x0)**2 + (y-y0)**2 + (z-z0)**2)/sig2)
    !       end if
    !     end do
    !   end do
    ! end do
    !b_loc = 0.0_real64  ! override with zero for now, to test homogeneous BCs and solver convergence without a source
    write(*,*) "Value of the sum", sum(b_loc)
  end subroutine build_rhs_gaussian

  subroutine write_mco_real_xy(fname, a, nx, ny, kslice, rank)
    use iso_fortran_env, only: real64
    implicit none
    character(len=*), intent(in) :: fname
    real(real64),     intent(in) :: a(0:nx+2,0:ny+2,*)
    integer,          intent(in) :: nx, ny, kslice, rank
    integer :: i, j, u

    if (rank /= 0) return

    open(newunit=u, file=fname, status="replace", action="write", form="formatted")

    ! header consistent with your legacy-style 2D MCO slices (interior 1..nx+1, 1..ny+1)
    write(u,'(2I8)') nx+1, ny+1

    do j = ny+1, 1, -1
      do i = 1, nx+1
        write(u,'(ES24.16)', advance='no') a(i,j,kslice)
      end do
      write(u,*)
    end do

    close(u)
  end subroutine write_mco_real_xy

end module mod_poisson_stub_driver
