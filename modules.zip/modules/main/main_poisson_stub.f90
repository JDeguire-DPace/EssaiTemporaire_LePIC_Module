program main_poisson_stub
  use iso_fortran_env, only: int32, real64
  use mpi
  use mod_config,         only: Config
  use mod_readConditions, only: read_input
  use mod_domain,         only: Domain
  use mod_fields,         only: Fields
  use mod_poisson_stub_driver, only: run_poisson_stub
  use mod_boundary,       only: build_boundary
  implicit none

  integer :: ierr, rank
  integer :: comm
  type(Config) :: cfg
  type(Domain) :: dom
  type(Fields) :: fld

  call MPI_Init(ierr)
  comm = MPI_COMM_WORLD
  call MPI_Comm_rank(comm, rank, ierr)

  ! Read conditions.inp -> cfg
  call read_input(cfg, rank)

  ! Domain + fields
  call dom%init_from_config(cfg)
  call dom%allocate_masks_domain()
  call fld%allocate_from_domain(dom)
  call fld%zero()

  ! Build boundary (fills dom%bcnd, dom%h, and sets wall phi in fld%phi)
  call build_boundary(dom, cfg, fld, rank)

  ! Run stub Poisson solve (scatter/build RHS/optional legacy pdesolver/gather)
  call run_poisson_stub(comm, dom%n, dom%h, dom%bcnd, fld%phi)

  call MPI_Finalize(ierr)
end program main_poisson_stub
